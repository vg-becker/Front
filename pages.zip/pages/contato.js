import Menu from '../components/Menu';
import { Spinner } from 'reactstrap';
import {jumbotron, Container} from 'reactstrap'
import 'bootstrap/dist/css/bootstrap.css';

function Contato() {
    return (
        <div>
            <Menu />
            <div className="jumbotron jumbotron-fluid">               
                <Container className='text-center'>
                    <div >
                        <h1 className="display-4">Contato</h1>
                        <p className="lead">"(xx) xxxx-xxxx"</p>
                    </div>
                </Container>
            </div>

            <div className="d-flex justify-content-center">
                <Spinner color="primary" />
            </div>
        </div>
    );
}

export default Contato