import Head from 'next/head';
import Menu from '../components/Menu';
import { Jumbotron, Container } from 'reactstrap';

import 'bootstrap/dist/css/bootstrap.css';


function Home() {
    return (
        <div className="servico">
            <Head>
                <title>Home|GB store</title>
                <meta name='descripton' content='Site de Moda' />
                <meta nome='author' contente='Vitor Gabriel Becker' />
            </Head>
            <Menu />
            <div className="jumbotron jumbotron-fluid">               
                <Container className='text-center'>
                    <div >
                        <h1 className="display-4">Bem vindo</h1>
                        <p className="lead">Mussum Ipsum, cacilds vidis litro abertis. Quem manda na minha terra sou euzis!Si num tem leite então bota uma pinga aí cumpadi!Interagi no mé, cursus quis, vehicula ac nisi.Em pé sem cair, deitado sem dormir, sentado sem cochilar e fazendo pose.</p>
                    </div>
                </Container>
            </div>
            <div className="jumbotron jumbotron-fluid" >               
                <Container className='text-center'>
                    <div >
                        <h1 className="display-4">Hello Word</h1>
                        <p className="lead">Mussum Ipsum, cacilds vidis litro abertis. Quem num gosta di mé, boa gentis num é.In elementis mé pra quem é amistosis quis leo.Mais vale um bebadis conhecidiss, que um alcoolatra anonimis.Si num tem leite então bota uma pinga aí cumpadi!</p>
                    </div>
                </Container>
            </div>

        </div>

    );
}

export default Home;