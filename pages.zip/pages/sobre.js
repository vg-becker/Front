import Menu from '../components/Menu';
import 'bootstrap/dist/css/bootstrap.css';
import {jumbotron, Container} from 'reactstrap'

function Sobre() {
    return (
        <div>
            <Menu /> 
            <div className="jumbotron jumbotron-fluid">               
                <Container className='text-center'>
                    <div >
                        <h1 className="display-4">Sobre</h1>
                        <p className="lead">Mussum Ipsum, cacilds vidis litro abertis. Quem manda na minha terra sou euzis!Nec orci ornare consequat. Praesent lacinia ultrices consectetur. Sed non ipsum felis.Manduma pindureta quium dia nois paga.Posuere libero varius. Nullam a nisl ut ante blandit hendrerit. Aenean sit amet nisi.</p>
                    </div>
                </Container>
            </div>
        </div>
    )
}

export default Sobre